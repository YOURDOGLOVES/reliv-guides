/* @ds-bundle: {"format":4,"namespace":"HamitDesignSystem_55b100","components":[{"name":"BadgePill","sourcePath":"components/badges/BadgePill.jsx"},{"name":"CategoryTab","sourcePath":"components/badges/CategoryTab.jsx"},{"name":"Button","sourcePath":"components/buttons/Button.jsx"},{"name":"TextLink","sourcePath":"components/buttons/TextLink.jsx"},{"name":"ExpertCard","sourcePath":"components/cards/ExpertCard.jsx"},{"name":"FeatureCard","sourcePath":"components/cards/FeatureCard.jsx"},{"name":"HeroIllustrationCard","sourcePath":"components/cards/HeroIllustrationCard.jsx"},{"name":"PricingTierCard","sourcePath":"components/cards/PricingTierCard.jsx"},{"name":"ProductMockupCard","sourcePath":"components/cards/ProductMockupCard.jsx"},{"name":"TestimonialCard","sourcePath":"components/cards/TestimonialCard.jsx"},{"name":"TextInput","sourcePath":"components/forms/TextInput.jsx"},{"name":"CtaBandIllustrated","sourcePath":"components/layout/CtaBandIllustrated.jsx"},{"name":"Footer","sourcePath":"components/layout/Footer.jsx"},{"name":"HeroBand","sourcePath":"components/layout/HeroBand.jsx"},{"name":"TopNav","sourcePath":"components/navigation/TopNav.jsx"}],"sourceHashes":{"components/badges/BadgePill.jsx":"462fcfaf926b","components/badges/CategoryTab.jsx":"e23ceb03df0c","components/buttons/Button.jsx":"426f8d2bb2a3","components/buttons/TextLink.jsx":"906e27365eb0","components/cards/ExpertCard.jsx":"6e6d6c9cbb58","components/cards/FeatureCard.jsx":"c6b7e6cddc85","components/cards/HeroIllustrationCard.jsx":"45adee4b7f89","components/cards/PricingTierCard.jsx":"40c5ed6dcc6e","components/cards/ProductMockupCard.jsx":"ffad420f7043","components/cards/TestimonialCard.jsx":"01e0d6b3ca0d","components/forms/TextInput.jsx":"45bc4a93bd21","components/layout/CtaBandIllustrated.jsx":"7879c60f5bf1","components/layout/Footer.jsx":"bffff0fc8d77","components/layout/HeroBand.jsx":"088aa46d6312","components/navigation/TopNav.jsx":"cde76ac81d4e","ui_kits/marketing-site/HomePage.jsx":"52b4885f1e22"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.HamitDesignSystem_55b100 = window.HamitDesignSystem_55b100 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/badges/BadgePill.jsx
try { (() => {
function BadgePill({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-caption-size)',
      fontWeight: 'var(--text-caption-weight)',
      color: 'var(--color-body)',
      background: 'var(--color-surface-card)',
      borderRadius: 'var(--radius-pill)',
      padding: '6px 14px',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { BadgePill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/badges/BadgePill.jsx", error: String((e && e.message) || e) }); }

// components/badges/CategoryTab.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function CategoryTab({
  children,
  active = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-nav-link-size)',
      fontWeight: 500,
      padding: '8px 16px',
      borderRadius: 'var(--radius-pill)',
      border: 'none',
      cursor: 'pointer',
      background: active ? 'var(--color-surface-card)' : 'transparent',
      color: active ? 'var(--color-ink)' : 'var(--color-muted)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { CategoryTab });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/badges/CategoryTab.jsx", error: String((e && e.message) || e) }); }

// components/buttons/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  variant = 'primary',
  children,
  onClick,
  type = 'button',
  style,
  ...rest
}) {
  const base = {
    fontFamily: 'var(--font-body)',
    fontSize: 'var(--text-button-size)',
    fontWeight: 'var(--text-button-weight)',
    lineHeight: 'var(--text-button-lh)',
    borderRadius: 'var(--radius-md)',
    padding: '12px 20px',
    height: 44,
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    border: 'none',
    cursor: 'pointer',
    boxSizing: 'border-box',
    whiteSpace: 'nowrap'
  };
  const variants = {
    primary: {
      background: 'var(--color-primary)',
      color: 'var(--color-on-primary)'
    },
    secondary: {
      background: 'var(--color-canvas)',
      color: 'var(--color-ink)',
      border: 'var(--border-hairline)'
    },
    'on-color': {
      background: '#ffffff',
      color: 'var(--color-ink)'
    },
    'text-link': {
      background: 'transparent',
      color: 'var(--color-ink)',
      padding: 0,
      height: 'auto',
      textDecoration: 'underline'
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    onClick: onClick,
    style: {
      ...base,
      ...(variants[variant] || variants.primary),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/Button.jsx", error: String((e && e.message) || e) }); }

// components/buttons/TextLink.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TextLink({
  children,
  href = '#',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    style: {
      color: 'var(--color-ink)',
      textDecoration: 'underline',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-md-size)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { TextLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/TextLink.jsx", error: String((e && e.message) || e) }); }

// components/cards/ExpertCard.jsx
try { (() => {
function ExpertCard({
  name,
  specialization,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-canvas)',
      border: 'var(--border-hairline)',
      borderRadius: 'var(--radius-lg)',
      padding: 'var(--space-lg)',
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      fontFamily: 'var(--font-body)',
      alignItems: 'flex-start',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 48,
      height: 48,
      borderRadius: 'var(--radius-full)',
      background: 'var(--color-surface-strong)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-title-sm-size)',
      fontWeight: 600,
      color: 'var(--color-ink)'
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-body-sm-size)',
      color: 'var(--color-muted)'
    }
  }, specialization), /*#__PURE__*/React.createElement(__ds_scope.TextLink, {
    href: "#"
  }, "Book session"));
}
Object.assign(__ds_scope, { ExpertCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ExpertCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/FeatureCard.jsx
try { (() => {
const bg = {
  pink: 'var(--color-brand-pink)',
  teal: 'var(--color-brand-teal)',
  lavender: 'var(--color-brand-lavender)',
  peach: 'var(--color-brand-peach)',
  ochre: 'var(--color-brand-ochre)',
  cream: 'var(--color-surface-card)'
};
const darkText = ['pink', 'teal'];
function FeatureCard({
  variant = 'cream',
  title,
  description,
  children,
  style
}) {
  const isDark = darkText.includes(variant);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: bg[variant] || bg.cream,
      borderRadius: 'var(--radius-xl)',
      padding: 'var(--space-xl)',
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      boxSizing: 'border-box',
      color: isDark ? 'var(--color-on-dark)' : 'var(--color-ink)',
      fontFamily: 'var(--font-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-title-md-size)',
      fontWeight: 'var(--text-title-md-weight)',
      margin: 0
    }
  }, title), description && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--text-body-md-size)',
      lineHeight: 'var(--text-body-md-lh)',
      opacity: 0.9
    }
  }, description), children);
}
Object.assign(__ds_scope, { FeatureCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/FeatureCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/HeroIllustrationCard.jsx
try { (() => {
function HeroIllustrationCard({
  label = '3D illustration',
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-surface-soft)',
      borderRadius: 'var(--radius-xl)',
      minHeight: 320,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: '1px dashed var(--color-hairline)',
      fontFamily: 'var(--font-body)',
      color: 'var(--color-muted-soft)',
      fontSize: 'var(--text-caption-size)',
      ...style
    }
  }, label);
}
Object.assign(__ds_scope, { HeroIllustrationCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/HeroIllustrationCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/PricingTierCard.jsx
try { (() => {
function PricingTierCard({
  name,
  price,
  features = [],
  featured = false,
  style
}) {
  const dark = featured;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: featured ? 'var(--color-brand-teal)' : 'var(--color-canvas)',
      border: featured ? 'none' : 'var(--border-hairline)',
      borderRadius: 'var(--radius-lg)',
      padding: 'var(--space-xl)',
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      fontFamily: 'var(--font-body)',
      color: dark ? 'var(--color-on-dark)' : 'var(--color-ink)',
      boxSizing: 'border-box',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-title-lg-size)',
      fontWeight: 'var(--text-title-lg-weight)'
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-display-sm-size)',
      fontWeight: 500,
      marginTop: 8
    }
  }, price)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, features.map(f => /*#__PURE__*/React.createElement("div", {
    key: f,
    style: {
      fontSize: 'var(--text-body-sm-size)',
      opacity: 0.9
    }
  }, f))), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: featured ? 'on-color' : 'secondary'
  }, "Get started"));
}
Object.assign(__ds_scope, { PricingTierCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/PricingTierCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/ProductMockupCard.jsx
try { (() => {
function ProductMockupCard({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-canvas)',
      border: 'var(--border-hairline)',
      borderRadius: 'var(--radius-lg)',
      padding: 'var(--space-lg)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-sm-size)',
      color: 'var(--color-body)',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { ProductMockupCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ProductMockupCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/TestimonialCard.jsx
try { (() => {
function TestimonialCard({
  quote,
  name,
  role,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-surface-card)',
      borderRadius: 'var(--radius-lg)',
      padding: 'var(--space-lg)',
      fontFamily: 'var(--font-body)',
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      borderRadius: 'var(--radius-full)',
      background: 'var(--color-surface-strong)'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-title-sm-size)',
      fontWeight: 600,
      color: 'var(--color-ink)'
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-caption-size)',
      color: 'var(--color-muted)'
    }
  }, role))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--text-body-md-size)',
      lineHeight: 'var(--text-body-md-lh)',
      color: 'var(--color-body)'
    }
  }, quote));
}
Object.assign(__ds_scope, { TestimonialCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/TestimonialCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextInput.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TextInput({
  placeholder,
  value,
  onChange,
  focused = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("input", _extends({
    placeholder: placeholder,
    value: value,
    onChange: onChange,
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-md-size)',
      color: 'var(--color-ink)',
      borderRadius: 'var(--radius-md)',
      padding: '12px 16px',
      height: 44,
      boxSizing: 'border-box',
      background: 'var(--color-canvas)',
      border: focused ? '1.5px solid var(--color-ink)' : 'var(--border-hairline)',
      outline: 'none',
      width: '100%',
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { TextInput });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextInput.jsx", error: String((e && e.message) || e) }); }

// components/layout/CtaBandIllustrated.jsx
try { (() => {
function CtaBandIllustrated({
  title,
  subtitle,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-surface-soft)',
      borderRadius: 'var(--radius-xl)',
      padding: '80px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      gap: 20,
      fontFamily: 'var(--font-body)',
      boxSizing: 'border-box',
      ...style
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-display-md-size)',
      fontWeight: 'var(--text-display-md-weight)',
      letterSpacing: 'var(--text-display-md-ls)',
      margin: 0,
      color: 'var(--color-ink)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--text-title-md-size)',
      color: 'var(--color-body)'
    }
  }, subtitle), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary"
  }, "Try free"));
}
Object.assign(__ds_scope, { CtaBandIllustrated });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/CtaBandIllustrated.jsx", error: String((e && e.message) || e) }); }

// components/layout/Footer.jsx
try { (() => {
const cols = [{
  h: 'Product',
  items: ['Sequences', 'Enrichment', 'Claygent', 'Integrations']
}, {
  h: 'Solutions',
  items: ['Sales', 'Recruiting', 'Marketing']
}, {
  h: 'Resources',
  items: ['Docs', 'Blog', 'Templates', 'Experts']
}, {
  h: 'Company',
  items: ['About', 'Careers', 'Customers']
}];
function Footer({
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-surface-soft)',
      padding: '80px 32px 40px',
      fontFamily: 'var(--font-body)',
      boxSizing: 'border-box',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 32,
      maxWidth: 'var(--container-max)',
      margin: '0 auto'
    }
  }, cols.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.h,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-title-sm-size)',
      fontWeight: 600,
      color: 'var(--color-ink)'
    }
  }, c.h), c.items.map(i => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      fontSize: 'var(--text-body-sm-size)',
      color: 'var(--color-body)'
    }
  }, i))))), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginTop: 56,
      fontSize: 'var(--text-caption-size)',
      color: 'var(--color-muted-soft)'
    }
  }, "\xA9 2026 Hamit"));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Footer.jsx", error: String((e && e.message) || e) }); }

// components/layout/HeroBand.jsx
try { (() => {
function HeroBand({
  eyebrow,
  title,
  subtitle,
  illustrationLabel,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-canvas)',
      padding: 'var(--space-section) 32px',
      display: 'grid',
      gridTemplateColumns: '7fr 5fr',
      gap: 48,
      alignItems: 'center',
      fontFamily: 'var(--font-body)',
      boxSizing: 'border-box',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      alignItems: 'flex-start'
    }
  }, eyebrow && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-caption-uppercase-size)',
      fontWeight: 'var(--text-caption-uppercase-weight)',
      letterSpacing: 'var(--text-caption-uppercase-ls)',
      color: 'var(--color-muted)',
      textTransform: 'uppercase'
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-display-xl-size)',
      fontWeight: 'var(--text-display-xl-weight)',
      lineHeight: 'var(--text-display-xl-lh)',
      letterSpacing: 'var(--text-display-xl-ls)',
      margin: 0,
      color: 'var(--color-ink)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-title-md-size)',
      color: 'var(--color-body)',
      margin: 0,
      maxWidth: 480
    }
  }, subtitle), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary"
  }, "Try free"), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "secondary"
  }, "Book a demo"))), /*#__PURE__*/React.createElement(__ds_scope.HeroIllustrationCard, {
    label: illustrationLabel
  }));
}
Object.assign(__ds_scope, { HeroBand });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/HeroBand.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TopNav.jsx
try { (() => {
function TopNav({
  items = ['Product', 'Solutions', 'Resources', 'Pricing', 'Customers']
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      height: 64,
      padding: '0 32px',
      background: 'var(--color-canvas)',
      boxSizing: 'border-box',
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 20,
      letterSpacing: '-0.5px',
      color: 'var(--color-ink)'
    }
  }, "Hamit"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 28
    }
  }, items.map(i => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      fontSize: 'var(--text-nav-link-size)',
      fontWeight: 'var(--text-nav-link-weight)',
      color: 'var(--color-body)',
      cursor: 'pointer'
    }
  }, i))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "text-link",
    style: {
      textDecoration: 'none',
      fontWeight: 500
    }
  }, "Sign in"), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary"
  }, "Try free")));
}
Object.assign(__ds_scope, { TopNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TopNav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/marketing-site/HomePage.jsx
try { (() => {
const {
  TopNav,
  HeroBand,
  FeatureCard,
  ProductMockupCard,
  TestimonialCard,
  PricingTierCard,
  CategoryTab,
  ExpertCard,
  CtaBandIllustrated,
  Footer
} = window.HamitDesignSystem_55b100;
function HomePage() {
  const [tab, setTab] = React.useState('All');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      background: 'var(--color-canvas)'
    }
  }, /*#__PURE__*/React.createElement(TopNav, null), /*#__PURE__*/React.createElement(HeroBand, {
    eyebrow: "GTM data",
    title: "Go to market with unique data",
    subtitle: "Find, enrich, and act on the data other platforms can't reach \u2014 all from one clay-simple interface.",
    illustrationLabel: "Mascot on mountain \u2014 3D illustration"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 32px var(--space-section)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 32
    }
  }, ['All', 'Sales', 'Marketing', 'Recruiting'].map(t => /*#__PURE__*/React.createElement(CategoryTab, {
    key: t,
    active: tab === t,
    onClick: () => setTab(t)
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(FeatureCard, {
    variant: "pink",
    title: "Sequences",
    description: "Automate outbound at scale with dynamic, data-driven sequences."
  }, /*#__PURE__*/React.createElement(ProductMockupCard, null, "Step 3 \xB7 Sent 1,204 emails \xB7 42% open rate")), /*#__PURE__*/React.createElement(FeatureCard, {
    variant: "teal",
    title: "Enterprise workspace",
    description: "Governance, SSO, and shared credit pools for GTM teams."
  }, /*#__PURE__*/React.createElement(ProductMockupCard, {
    style: {
      background: 'var(--color-surface-dark-elevated)',
      border: 'none',
      color: '#fff'
    }
  }, "12 workspaces \xB7 340 seats")), /*#__PURE__*/React.createElement(FeatureCard, {
    variant: "lavender",
    title: "Claygent",
    description: "An AI agent that researches any company or person on the web."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    variant: "peach",
    title: "Enrichment",
    description: "Waterfall 100+ data providers into one clean record."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    variant: "ochre",
    title: "Experts",
    description: "Book time with GTM experts who've built this before."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    variant: "cream",
    title: "Integrations",
    description: "Push data anywhere \u2014 CRM, sequencer, ads, and more."
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-surface-soft)',
      padding: 'var(--space-section) 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(TestimonialCard, {
    name: "Jamie Lin",
    role: "Head of Growth, Northwind",
    quote: "We replaced four tools and doubled qualified pipeline in a quarter."
  }), /*#__PURE__*/React.createElement(TestimonialCard, {
    name: "Andre Silva",
    role: "RevOps Lead, Fenwick",
    quote: "Claygent found account context our SDRs used to spend hours digging for."
  }), /*#__PURE__*/React.createElement(TestimonialCard, {
    name: "Priya Shah",
    role: "Founder, Loomline",
    quote: "The enrichment waterfall alone paid for the whole platform."
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: 'var(--space-section) 32px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-display-md-size)',
      fontWeight: 500,
      letterSpacing: 'var(--text-display-md-ls)',
      marginBottom: 32
    }
  }, "Simple, credit-based pricing"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement(PricingTierCard, {
    name: "Starter",
    price: "$149/mo",
    features: ['5 seats', '10k credits', 'Email support']
  }), /*#__PURE__*/React.createElement(PricingTierCard, {
    name: "Growth",
    price: "$499/mo",
    features: ['20 seats', '100k credits', 'Priority support'],
    featured: true
  }), /*#__PURE__*/React.createElement(PricingTierCard, {
    name: "Enterprise",
    price: "Custom",
    features: ['Unlimited seats', 'SSO & governance', 'Dedicated CSM']
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 32px var(--space-section)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-display-sm-size)',
      fontWeight: 500,
      marginBottom: 24
    }
  }, "Talk to an expert"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(ExpertCard, {
    name: "Priya Shah",
    specialization: "Outbound sequencing"
  }), /*#__PURE__*/React.createElement(ExpertCard, {
    name: "Andre Silva",
    specialization: "RevOps & data hygiene"
  }), /*#__PURE__*/React.createElement(ExpertCard, {
    name: "Jamie Lin",
    specialization: "Growth & lifecycle"
  }), /*#__PURE__*/React.createElement(ExpertCard, {
    name: "Kofi Mensah",
    specialization: "Enrichment waterfalls"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 32px'
    }
  }, /*#__PURE__*/React.createElement(CtaBandIllustrated, {
    title: "Turn your growth ideas into reality today",
    subtitle: "Start free \u2014 no credit card required."
  })), /*#__PURE__*/React.createElement(Footer, null));
}
window.HomePage = HomePage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing-site/HomePage.jsx", error: String((e && e.message) || e) }); }

__ds_ns.BadgePill = __ds_scope.BadgePill;

__ds_ns.CategoryTab = __ds_scope.CategoryTab;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.TextLink = __ds_scope.TextLink;

__ds_ns.ExpertCard = __ds_scope.ExpertCard;

__ds_ns.FeatureCard = __ds_scope.FeatureCard;

__ds_ns.HeroIllustrationCard = __ds_scope.HeroIllustrationCard;

__ds_ns.PricingTierCard = __ds_scope.PricingTierCard;

__ds_ns.ProductMockupCard = __ds_scope.ProductMockupCard;

__ds_ns.TestimonialCard = __ds_scope.TestimonialCard;

__ds_ns.TextInput = __ds_scope.TextInput;

__ds_ns.CtaBandIllustrated = __ds_scope.CtaBandIllustrated;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.HeroBand = __ds_scope.HeroBand;

__ds_ns.TopNav = __ds_scope.TopNav;

})();
