# Hamit Design System

## Overview

Hamit is built on a **playful, warm B2B-SaaS visual language** — a cream-tinted canvas, saturated single-color feature cards, and hand-crafted-feeling 3D illustrations in place of the cool-gray, gradient-heavy conventions of typical GTM/data-platform sites.

**Source of this system:** no Figma file, codebase, or slide deck was attached. Everything here (tokens, components, homepage) was built directly from a detailed written brand brief pasted into this project (colors, type scale, spacing, component inventory, do's/don'ts, responsive rules). If a Figma link, GitHub repo, or codebase exists for Hamit, re-attach it and this system should be reconciled against the real source — written specs are a starting point, not ground truth.

Logo: `assets/logo-white.png` (white mark, transparent PNG — for use on dark/saturated backgrounds). Only a white variant has been provided; use plain wordmark type on light/cream backgrounds until a dark/color variant is supplied.

## Content Fundamentals

(Derived from the brief's own copy examples — e.g. "Go to market with unique data", "Turn your growth ideas into reality today".)

- **Voice:** direct, low-hype, product-first. Headlines state the *outcome* ("Go to market with unique data") rather than adjectives about the product.
- **Casing:** sentence case throughout — headlines, buttons, nav items. No title case, no ALL CAPS except the 12px uppercase caption/eyebrow token (`caption-uppercase`), which is used sparingly for section labels.
- **Person:** second person ("your growth ideas") for CTA/benefit copy; third person/descriptive for feature names and card titles.
- **Length:** short. Headlines are one line; feature-card descriptions are one sentence.
- **Emoji:** never used.
- **Buttons:** verb-first, 1-3 words ("Try free", "Book a demo", "Get started").

## Visual Foundations

- **Canvas:** cream-tinted white (`--color-canvas`, #fffaf0) everywhere — never cool gray or pure white. This warmth is the single most load-bearing brand cue.
- **Type:** display headlines want "Plain Black" (a licensed custom rounded face) at weight 500 only, with negative letter-spacing (-1 to -2.5px at large sizes) — never bolder. **Not available as a web font**; this system substitutes **Inter 500** with the same negative letter-spacing, loaded via Google Fonts. Body/UI text is Inter at regular weights. See "Known Substitutions" below.
- **Color voltage:** a 6-color saturated palette (pink, teal, lavender, peach, ochre, cream) used exclusively as full-bleed feature-card fills — never as text color, never as small accents. Cycle colors across a page; never repeat one back-to-back. Pink/teal are dark enough to need white text; lavender/peach/ochre/cream keep dark ink text.
- **Backgrounds:** flat color fields only. No photography, no gradients, no repeating textures/patterns in this system. The brief calls for full-bleed 3D "claymation" illustrations (mountains, mascot characters) as hero/CTA artifacts — no such assets were provided, so hero/CTA illustration slots render as labeled dashed placeholders (`HeroIllustrationCard`). Swap in real renders before shipping.
- **Shadows:** effectively none. Depth comes from color contrast (cream canvas vs. saturated card) and a single 1px hairline border (`--color-hairline`) on inputs and neutral cards — not from elevation/shadow systems.
- **Corners:** generous and scales with size — 6px (badges) → 8px (small buttons) → 12px (buttons/inputs) → 16px (content cards) → 24px (feature cards) → pill (tabs/badges).
- **Cards:** two families only — saturated color-fill feature cards (no border, no shadow, 24px radius) and cream/canvas neutral cards (hairline border, 16px radius). No card in this system uses a drop shadow as its primary depth cue.
- **Hover/press:** the brief explicitly avoids documenting hover/press styling beyond what's already encoded in color contrast — no separate hover/active tokens exist. Don't invent them.
- **Transparency/blur:** not used anywhere in this system.
- **Imagery color vibe:** N/A — no photography in the system; illustration accents (when supplied) run warm (peach/ochre/mint) per the brief.
- **Layout rhythm:** 96px (`--space-section`) between major bands; 1280px max content width; hero uses a 7/5 split (copy left, illustration right).
- **Footer:** cream, never dark — a deliberate departure from typical SaaS dark footers.

## Iconography

No icon set, icon font, or SVG sprite was included in the attached brief, so **no icon assets exist in this system**. Avatars render as flat cream/tan circles (`--color-surface-strong`) rather than photos or icon glyphs. If Hamit uses a specific icon library in production (Lucide, Phosphor, custom), attach it and this section should be updated — do not hand-roll icon SVGs in the meantime.

## Known Substitutions (flagged — please provide real assets)

1. **Typeface:** "Plain Black" is unavailable; **Inter 500** with negative letter-spacing stands in, per the brief's own documented fallback guidance. If you have Plain Black's font files (or a license), attach them and this system will switch to real `@font-face` declarations.
2. **Logo/wordmark:** none provided — plain-type "Hamit" used everywhere a mark would appear.
3. **3D claymation illustrations:** none provided — `HeroIllustrationCard` renders a labeled placeholder. These are commissioned per-page assets in the source brief, not systemizable tokens; real renders are needed for production use.
4. **Icons:** none provided — no icon usage anywhere in this system yet.

## Index

- `styles.css` — root stylesheet, imports everything under `tokens/`.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `radius.css`, `elevation.css`.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand groups in the Design System tab).
- `components/` — reusable primitives, grouped by concern:
  - `buttons/` — `Button` (primary/secondary/on-color/text-link), `TextLink`
  - `forms/` — `TextInput`
  - `badges/` — `BadgePill`, `CategoryTab`
  - `navigation/` — `TopNav`
  - `cards/` — `FeatureCard` (6 color variants), `ProductMockupCard`, `TestimonialCard`, `PricingTierCard` (+featured), `ExpertCard`, `HeroIllustrationCard`
  - `layout/` — `HeroBand`, `CtaBandIllustrated`, `Footer`
- `ui_kits/marketing-site/` — full homepage recreation (`index.html`, `HomePage.jsx`) built from the components above.
- `thumbnail.html` — project tile for the homepage picker.
- `SKILL.md` — portable skill definition for use in Claude Code / other agent environments.

### Intentional additions
None — every component above traces to an explicit entry in the brief's own "Components" section (`top-nav`, `button-*`, `hero-band`, `hero-illustration-card`, `feature-card-*`, `product-mockup-card`, `testimonial-card`, `pricing-tier-card*`, `expert-card`, `text-input*`, `category-tab*`, `badge-pill`, `cta-band-illustrated`, `footer`).
